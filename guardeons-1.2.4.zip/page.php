<?php
/** Page template */
get_header(); ?>
<main id="primary" class="site-main container">
<?php get_template_part('template-parts/components/breadcrumbs'); ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
  <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="entry-header">
      <?php the_title('<h1 class="entry-title">', '</h1>'); ?>
    </header>
    <div class="entry-content">
      <?php the_content(); ?>
    </div>
  </article>
<?php endwhile; endif; ?>
</main>
<?php get_footer(); ?>